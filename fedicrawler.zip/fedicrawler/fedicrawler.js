const axios = require('axios');
const visitedServers = new Set();

async function fetchPeers(serverUrl) {
    try {
      const response = await axios.get(`https://${serverUrl}/api/v1/instance/peers`);
      const data = response.data;
  
      if (Array.isArray(data)) {
        return data;
      } else {
        console.error(`Unexpected response format from ${serverUrl}:`, data);
        return [];
      }
    } catch (error) {
      console.error(`Error fetching peers from ${serverUrl}:`, error.message);
      return [];
    }
  }
  

async function crawl(serverUrl) {
  if (visitedServers.has(serverUrl)) {
    return;
  }

  visitedServers.add(serverUrl);
  console.log(`Crawling: ${serverUrl}`);

  const peers = await fetchPeers(serverUrl);
  const unvisitedPeers = peers.filter(peer => !visitedServers.has(peer));

  const crawlPromises = unvisitedPeers.map(peer => crawl(peer));

  await Promise.all(crawlPromises);
}

(async () => {
  const startInstance = 'mstdn.jp';
  await crawl(startInstance);
  saveVisitedServers()
  console.log('Crawling completed.');
  console.log('Visited servers:', [...visitedServers]);
})();


function saveVisitedServers() {
    fs.writeFileSync('list.json', Array.from(servers_visited).join('\n'), 'utf8');
}


