let canvas = document.getElementById("canvas")
let ctx = canvas.getContext('2d')

let cameraOffset = { x: canvas.width/2, y: canvas.height/2 }
let cameraZoom = 1
let MAX_ZOOM = 10
let MIN_ZOOM = 1
let SCROLL_SENSITIVITY = 0.001



let myImage = new Image();


function loadImage(url) {
    myImage.onload = function() {
    
        requestAnimationFrame(draw);
    };
    myImage.src = url;
}






function draw()
{
    canvas.width = 1400
    canvas.height = 600
    // Clear the canvas before any transformations
    ctx.clearRect(0,0, canvas.width, canvas.height)
    
    // Translate to the canvas centre before zooming - so you'll always zoom on what you're looking directly at
    ctx.translate( canvas.width / 2, canvas.height / 2 )
    ctx.scale(cameraZoom, cameraZoom)
    ctx.translate( -canvas.width / 2 + cameraOffset.x, -canvas.height / 2 + cameraOffset.y )
    
    // Draw the image
    if (myImage.complete) { // Check if the image is loaded
        ctx.drawImage(myImage, 0, 0, myImage.width, myImage.height, -myImage.width / 2, -myImage.height / 2, myImage.width, myImage.height);
    } 
    
    requestAnimationFrame( draw )
}

// Gets the relevant location from a mouse or single touch event
function getEventLocation(e)
{
    if (e.touches && e.touches.length == 1)
    {
        return { x:e.touches[0].clientX, y: e.touches[0].clientY }
    }
    else if (e.clientX && e.clientY)
    {
        return { x: e.clientX, y: e.clientY }        
    }
}



let isDragging = false
let dragStart = { x: 0, y: 0 }

function onPointerDown(e)
{
    isDragging = true
    dragStart.x = getEventLocation(e).x/cameraZoom - cameraOffset.x
    dragStart.y = getEventLocation(e).y/cameraZoom - cameraOffset.y
}

function onPointerUp(e)
{
    isDragging = false
    initialPinchDistance = null
    lastZoom = cameraZoom
}

function onPointerMove(e)
{
    if (isDragging)
    {
        cameraOffset.x = getEventLocation(e).x/cameraZoom - dragStart.x
        cameraOffset.y = getEventLocation(e).y/cameraZoom - dragStart.y
    }
}

function handleTouch(e, singleTouchHandler)
{
    if ( e.touches.length == 1 )
    {
        singleTouchHandler(e)
    }
    else if (e.type == "touchmove" && e.touches.length == 2)
    {
        isDragging = false
        handlePinch(e)
    }
}

let initialPinchDistance = null
let lastZoom = cameraZoom

function handlePinch(e){
    e.preventDefault()
    
    let touch1 = { x: e.touches[0].clientX, y: e.touches[0].clientY }
    let touch2 = { x: e.touches[1].clientX, y: e.touches[1].clientY }
    
    // This is distance squared, but no need for an expensive sqrt as it's only used in ratio
    let currentDistance = (touch1.x - touch2.x)**2 + (touch1.y - touch2.y)**2
    
    if (initialPinchDistance == null)
    {
        initialPinchDistance = currentDistance
    }
    else
    {
        adjustZoom( null, currentDistance/initialPinchDistance )
    }
}

function adjustZoom(zoomAmount, zoomFactor)
{
    if (!isDragging)
    {
        if (zoomAmount)
        {
            cameraZoom += zoomAmount
        }
        else if (zoomFactor)
        {
            console.log(zoomFactor)
            cameraZoom = zoomFactor*lastZoom
        }
        
        cameraZoom = Math.min( cameraZoom, MAX_ZOOM )
        cameraZoom = Math.max( cameraZoom, MIN_ZOOM )
        
        console.log(zoomAmount)
    }
}

canvas.addEventListener('mousedown', onPointerDown)
canvas.addEventListener('touchstart', (e) => handleTouch(e, onPointerDown))
canvas.addEventListener('mouseup', onPointerUp)
canvas.addEventListener('touchend',  (e) => handleTouch(e, onPointerUp))
canvas.addEventListener('mousemove', onPointerMove)
canvas.addEventListener('touchmove', (e) => handleTouch(e, onPointerMove))
canvas.addEventListener( 'wheel', (e) => adjustZoom(e.deltaY*SCROLL_SENSITIVITY))


//きしょきしょ♡グローバル変数ゾーン
let map = 0;



window.onload = function(){
    load(map)
    pindraw()
    loadjson()
};

function pindraw(){
    const canvas = document.getElementById("pin");
    const ctx = canvas.getContext("2d");
    ctx.fillRect(700, 300, 2, 20);
    ctx.fillRect(700, 300, 20, 2);
    ctx.fillRect(700, 300, 2, -20);
    ctx.fillRect(700, 300, -20, 2);
};

function info (cname){
    let canvas = document.getElementById("info");
    let ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, 1400, 600);
    ctx.font = "48px serif";
    ctx.fillText(map + "P" + ":" + cname, 10, 50);
};

function load(mapid){
    loadImage(mapid + ".svg")
    draw()
};

function next (){
    if (map < 1){
    map = map + 1
    load(map)
    };
};

function prev (){
    if (map > 0){
    map = map - 1
    load(map)
    };
};



function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
};

async function callcname(){
    while(true){
        await sleep(100)
        rgb()
    };
};



function rgb (){
    let imageData = ctx.getImageData(700, 300, 1, 1);
    let data = imageData.data;
    let r = data[0];
    let g = data[1];
    let b = data[2];
    calljson (rgbToHex(r, g, b));
};

function rgbToHex(r, g, b) {
    // 各色を16進数に変換し、必要であれば先頭に0を付け加える
    const hex = (r << 16 | g << 8 | b).toString(16);
    return '#' + hex.padStart(6, '0');
};

function cname (cty){
    console.log(cty);
};


function loadjson() {
    // JSONファイルのURLを格納する配列
    const urls = ['0.json', '1.json'];

    // 各URLに対するfetch処理のPromiseを格納する配列
    const promises = urls.map(url => fetch(url, {
        method: 'GET', // HTTPメソッド
        cache: 'no-cache', // キャッシュを無効にする
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('ネットワークレスポンスが正常ではありません');
        }
        return response.json(); // JSONとしてレスポンスボディを解析
    }));

    // すべての非同期処理が完了した後の処理
    Promise.all(promises)
        .then(data => {
            // data[0]には '0.json' の内容が、data[1]には '1.json' の内容が格納されている
            json0 = data[0];
            json1 = data[1];
            // 必要な処理をここに記述
            callcname()

        })
        .catch(error => {
            console.error('問題が発生しました:', error);
        });
};


function calljson (hex){
    const jsonObjects = {
    json0: json0,
    json1: json1
    };


let jsonname = "json" + map; // この変数に格納されている名前で動的にオブジェクトにアクセスします。

let cname = (jsonObjects[jsonname][hex]); // 正しく#ff0000を出力します。
console.log(cname)
if (cname === undefined){
info("sea")
} else {
info(cname)
}
};




